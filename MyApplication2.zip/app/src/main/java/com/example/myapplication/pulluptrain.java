package com.example.myapplication;

import android.os.Bundle;
import android.widget.NumberPicker;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class pulluptrain extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.pulluptrain_xml);

        NumberPicker npker = findViewById(R.id.NumberPicker_pullup);

        npker.setMaxValue(100); //최대값
        npker.setMinValue(0); //최소값
        npker.setValue(50);// 초기값

		/* 만약 특정 문자열을 사용하고 싶으면
		npker.setDisplayedValues(string[]); */

        npker.setOnLongPressUpdateInterval(100); //길게 눌렀을 때 몇 초부터 반응?
        npker.setWrapSelectorWheel(true); //최대값 or 최소값에서 멈출지 넘어갈지
        npker.setOnScrollListener(new NumberPicker.OnScrollListener(){

            @Override
            public void onScrollStateChange(NumberPicker picker, int state)
            {
                switch (state) {
                    case SCROLL_STATE_FLING :
                        Toast.makeText(getApplicationContext(), "플링", Toast.LENGTH_SHORT).show();
                        break;
                    case SCROLL_STATE_TOUCH_SCROLL:
                        Toast.makeText(getApplicationContext(), "스크롤중", Toast.LENGTH_SHORT).show();
                        break;
                    case SCROLL_STATE_IDLE:

                        break;
                }

            }
        });

        npker.setOnValueChangedListener(new NumberPicker.OnValueChangeListener(){

            @Override
            public void onValueChange(NumberPicker picker, int oldVal, int newVal)
            {
                Toast.makeText(getApplicationContext(), "" + oldVal +"에서"+ newVal +"(으)로", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
